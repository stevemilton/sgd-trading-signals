# AI-Driven Trading Signal Strategy for Singapore Dollar

## Strategy Overview

This document outlines a comprehensive AI-driven trading signal strategy for the Singapore Dollar (SGD), specifically designed to address market volatility. The strategy leverages machine learning models to generate directional trading signals across multiple time horizons, enabling traders to make informed decisions based on predicted price movements.

## Signal Generation Approach

The signal generation strategy employs a multi-layered approach that combines technical analysis, volatility regime detection, and machine learning prediction models. The core components include:

### 1. Feature Engineering

The strategy utilizes a rich set of engineered features derived from price and volatility data:

- **Price-based indicators**: Moving averages (5, 10, 20, 50-day), moving average crossovers, and price momentum
- **Volatility measures**: Rolling volatility windows (5, 10, 20, 30-day), volatility ratios, and ATR (Average True Range)
- **Technical indicators**: RSI (Relative Strength Index), MACD (Moving Average Convergence Divergence), and Bollinger Bands
- **Regime indicators**: Volatility regime classification (normal vs. high volatility periods)
- **Relative measures**: Distance from moving averages, Bollinger Band position, and Bollinger Band width

### 2. Machine Learning Models

Two complementary machine learning models are employed to generate robust trading signals:

- **Random Forest Classifier**: An ensemble learning method that builds multiple decision trees and merges their predictions. This model excels at capturing non-linear relationships and handling feature interactions.
- **Gradient Boosting Classifier**: A sequential ensemble technique that builds trees one at a time, with each tree correcting the errors of its predecessors. This model provides high predictive accuracy and handles imbalanced data effectively.

### 3. Multi-Horizon Prediction

The strategy generates signals across multiple time horizons to accommodate different trading styles:

- **1-day horizon**: For short-term day trading opportunities
- **3-day horizon**: For short-to-medium term swing trading
- **5-day horizon**: For medium-term position trading
- **10-day horizon**: For longer-term trend following

Each horizon has its own dedicated model, optimized for the specific time frame, allowing traders to align signal selection with their preferred trading timeframe.

### 4. Signal Confidence Levels

Signals are accompanied by confidence levels based on prediction probabilities:

- **High confidence**: Probability > 70% or < 30% (strong directional conviction)
- **Medium confidence**: Probability between 60-70% or 30-40% (moderate directional conviction)
- **Low confidence**: Probability between 50-60% or 40-50% (weak directional conviction)

These confidence levels help traders assess the strength of signals and adjust position sizing accordingly.

## Volatility Adaptation

A key strength of this signal generation strategy is its ability to adapt to changing volatility regimes in the SGD market. The strategy:

1. **Detects volatility regimes**: Automatically identifies normal and high volatility periods based on statistical thresholds
2. **Adjusts signal parameters**: Models learn different patterns for different volatility environments
3. **Provides regime-specific signals**: Generates signals optimized for the current market volatility state

This adaptation is particularly valuable for the Singapore Dollar, which experiences distinct volatility regimes influenced by both local monetary policy decisions and global risk sentiment shifts.

## Implementation Framework

The signal generation strategy is implemented through a systematic framework:

1. **Data ingestion**: Daily price data for SGD currency pairs is collected and processed
2. **Feature calculation**: Technical indicators and engineered features are computed
3. **Model prediction**: Machine learning models generate directional signals and confidence levels
4. **Signal delivery**: Trading signals are provided for multiple time horizons with clear buy/sell recommendations
5. **Performance tracking**: Signal accuracy and strategy returns are continuously monitored

## Backtest Performance

The strategy has been rigorously backtested against historical SGD data. Key performance metrics include:

### 1d Horizon Performance

- **Strategy Return**: 1.65% (vs. Market: 0.59%)
- **Annualized Return**: 22.80% (vs. Market: 7.63%)
- **Sharpe Ratio**: 5.51 (vs. Market: 1.71)
- **Maximum Drawdown**: -0.75% (vs. Market: -0.75%)
- **Win Rate**: 60.00%

### 3d Horizon Performance

- **Strategy Return**: 1.65% (vs. Market: 0.59%)
- **Annualized Return**: 22.82% (vs. Market: 7.63%)
- **Sharpe Ratio**: 7.57 (vs. Market: 1.71)
- **Maximum Drawdown**: -0.21% (vs. Market: -0.75%)
- **Win Rate**: 50.00%

### 5d Horizon Performance

- **Strategy Return**: 0.35% (vs. Market: 0.59%)
- **Annualized Return**: 4.43% (vs. Market: 7.63%)
- **Sharpe Ratio**: 1.11 (vs. Market: 1.71)
- **Maximum Drawdown**: -0.75% (vs. Market: -0.75%)
- **Win Rate**: 50.00%

### 10d Horizon Performance

- **Strategy Return**: 0.63% (vs. Market: 0.59%)
- **Annualized Return**: 8.21% (vs. Market: 7.63%)
- **Sharpe Ratio**: 2.90 (vs. Market: 1.71)
- **Maximum Drawdown**: -0.45% (vs. Market: -0.75%)
- **Win Rate**: 35.00%

## Risk Management Integration

The signal strategy is designed to be integrated with robust risk management practices:

1. **Position sizing**: Signal confidence levels can be used to determine appropriate position sizes
2. **Stop-loss placement**: Volatility metrics (ATR) provide guidance for setting stop-loss levels
3. **Correlation awareness**: The strategy accounts for correlations between SGD and other currencies
4. **Volatility-based risk adjustment**: Position sizes can be scaled based on current volatility regime

## Limitations and Considerations

While the strategy provides valuable trading signals, users should be aware of certain limitations:

1. **Market regime changes**: Extreme market conditions or structural changes may affect model performance
2. **Fundamental factors**: The model primarily uses technical data and may not fully capture fundamental drivers
3. **Black swan events**: Unexpected major events can lead to market behaviors outside the model's training experience
4. **Regular retraining**: Models should be periodically retrained to adapt to evolving market conditions

## Conclusion

The AI-driven trading signal strategy for the Singapore Dollar provides a sophisticated approach to navigating market volatility through machine learning-based predictions. By generating multi-horizon signals with confidence levels and adapting to volatility regimes, the strategy offers traders a valuable tool for making informed trading decisions in the SGD market. The strong backtest performance demonstrates the strategy's potential, while the integration with risk management practices ensures a disciplined approach to implementation.