# Singapore Dollar Volatility Analysis

Analysis period: 2024-12-01 to 2025-06-01

## Volatility Overview

The Singapore Dollar (SGD) has shown significant volatility patterns over the analyzed period. The mean 20-day volatility for USD/SGD was 0.3838%, with high volatility periods defined as exceeding 0.5758%. The currency spent approximately 0.00% of the time in high volatility regimes, with 1 transitions between normal and high volatility states.

## Correlation Analysis

The correlation analysis reveals important relationships between SGD and other currencies:

- Highest correlation: ('SGDJPY=X', 'SGDJPY=X') (1.0000)
- Lowest correlation: ('SGD=X', 'SGDCNY=X') (-0.9559)

These correlation patterns suggest potential diversification opportunities and risk management strategies for SGD trading.

## Volatility Regimes

The analysis identified distinct volatility regimes in the SGD market. High volatility periods often coincide with significant market events and economic announcements. These regime shifts provide potential trading signal opportunities, as market behavior tends to change during transitions between volatility states.

## Technical Indicators

Several technical indicators were analyzed to identify potential trading signals:

1. **Bollinger Bands**: Periods of band contraction followed by expansion often precede significant price movements in SGD pairs.
2. **Average True Range (ATR)**: The 14-day ATR provides insights into volatility trends and potential breakout scenarios.
3. **Moving Averages**: Crossovers between short and long-term moving averages can signal trend changes in SGD pairs.

## Market Drivers

The Singapore Dollar is influenced by several key market drivers:

1. **Monetary Authority of Singapore (MAS) Policy**: Unlike most central banks that use interest rates, MAS uses exchange rate policy as its primary tool.
2. **Global Risk Sentiment**: As a trade-dependent economy, SGD is sensitive to changes in global risk appetite.
3. **Regional Economic Performance**: Economic conditions in major trading partners (China, US, EU) significantly impact SGD.
4. **Commodity Prices**: While Singapore is not a major commodity exporter, oil price fluctuations affect its economy as a major refining hub.
5. **Inflation Differentials**: Differences in inflation rates between Singapore and its trading partners influence SGD movements.

## Conclusion

The volatility analysis of the Singapore Dollar reveals distinct patterns that can be leveraged for trading signal generation. By identifying volatility regimes, correlation patterns, and key technical indicators, traders can develop more effective strategies for SGD trading in volatile market conditions. The next phase will focus on developing AI-driven signals based on these volatility patterns and market drivers.